import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://dnlptcxbhknahlabmiik.supabase.co'
const supabaseKey = 'sb_secret_Lb3aiG7Q1x-rE_yqWENEEA_A8htDWGD'

export const supabase = createClient(supabaseUrl, supabaseKey)
