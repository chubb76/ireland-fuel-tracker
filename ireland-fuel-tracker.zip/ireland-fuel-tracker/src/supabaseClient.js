import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://dnlptcxbhknahlabmiik.supabase.co'
const supabaseKey = 'sb_publishable_hXBq6rIl3l28HdMQTYH8Gw_qxsjLFaK'

export const supabase = createClient(supabaseUrl, supabaseKey)
