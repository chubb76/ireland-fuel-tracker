import { useState, useEffect, useMemo } from "react";
import { supabase } from "./supabaseClient";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer
} from "recharts";

const COUNTIES = [
  "Antrim","Armagh","Carlow","Cavan","Clare","Cork","Donegal","Down",
  "Dublin","Fermanagh","Galway","Kerry","Kildare","Kilkenny","Laois",
  "Leitrim","Limerick","Londonderry","Longford","Louth","Mayo","Meath",
  "Monaghan","Offaly","Roscommon","Sligo","Tipperary","Tyrone","Waterford",
  "Westmeath","Wexford","Wicklow"
];

const COORDS = {
  Dublin:[77,54],Wicklow:[76,63],Wexford:[72,73],Waterford:[59,77],
  Cork:[42,85],Kerry:[22,81],Limerick:[35,71],Clare:[29,63],
  Tipperary:[50,71],Kilkenny:[61,68],Carlow:[68,64],Kildare:[70,57],
  Laois:[60,59],Offaly:[54,52],Westmeath:[55,46],Longford:[51,40],
  Roscommon:[39,44],Galway:[25,55],Mayo:[21,40],Sligo:[35,28],
  Leitrim:[43,30],Cavan:[57,32],Monaghan:[61,26],Louth:[70,38],
  Meath:[65,46],Donegal:[33,14],
  Antrim:[68,18],Down:[72,28],Armagh:[63,26],Tyrone:[55,20],
  Fermanagh:[47,24],Londonderry:[53,12]
};

const FUEL_COLORS = { petrol:"#16a34a", diesel:"#2563eb", kerosene:"#f59e0b" };
const FUEL_ICONS  = { petrol:"⛽", diesel:"🛢️", kerosene:"🔥" };
const today = new Date().toISOString().split("T")[0];
const fmt = (v) => v != null ? `€${Number(v).toFixed(3)}` : "—";
const avg = (arr) => arr.length ? +(arr.reduce((s,x)=>s+x,0)/arr.length).toFixed(3) : undefined;

export default function App() {
  const [entries, setEntries]           = useState([]);
  const [loading, setLoading]           = useState(true);
  const [dbError, setDbError]           = useState(null);
  const [form, setForm]                 = useState({ county:"Dublin", station:"", petrol:"", diesel:"", kerosene:"", date:today });
  const [errors, setErrors]             = useState({});
  const [saving, setSaving]             = useState(false);
  const [activeTab, setActiveTab]       = useState("table");
  const [sortBy, setSortBy]             = useState("created_at");
  const [sortDir, setSortDir]           = useState("desc");
  const [mapFuel, setMapFuel]           = useState("petrol");
  const [filterCounty, setFilterCounty] = useState("All");
  const [liveCount, setLiveCount]       = useState(0);

  // ── Fetch all entries ────────────────────────────────────────────────────────
  const fetchEntries = async () => {
    const { data, error } = await supabase
      .from("fuel_prices")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) { setDbError(error.message); }
    else { setEntries(data || []); setDbError(null); }
    setLoading(false);
  };

  // ── Real-time subscription ───────────────────────────────────────────────────
  useEffect(() => {
    fetchEntries();
    const channel = supabase
      .channel("fuel_prices_realtime")
      .on("postgres_changes", { event: "*", schema: "public", table: "fuel_prices" }, () => {
        fetchEntries();
        setLiveCount(c => c + 1);
      })
      .subscribe();
    return () => supabase.removeChannel(channel);
  }, []);

  // ── Validation ───────────────────────────────────────────────────────────────
  const validate = () => {
    const e = {};
    if (!form.petrol && !form.diesel && !form.kerosene)
      e.price = "Please enter at least one price.";
    ["petrol","diesel","kerosene"].forEach(f => {
      if (form[f] && (isNaN(form[f]) || +form[f] <= 0 || +form[f] > 5))
        e[f] = "Must be between €0.01 – €5.00";
    });
    return e;
  };

  // ── Add entry ────────────────────────────────────────────────────────────────
  const addEntry = async () => {
    const e = validate();
    if (Object.keys(e).length) { setErrors(e); return; }
    setSaving(true);
    const { error } = await supabase.from("fuel_prices").insert({
      county:   form.county,
      station:  form.station.trim() || null,
      petrol:   form.petrol   ? parseFloat(form.petrol)   : null,
      diesel:   form.diesel   ? parseFloat(form.diesel)   : null,
      kerosene: form.kerosene ? parseFloat(form.kerosene) : null,
      date:     form.date,
    });
    setSaving(false);
    if (error) { setErrors({ price: error.message }); }
    else {
      setForm(f => ({ ...f, station:"", petrol:"", diesel:"", kerosene:"" }));
      setErrors({});
    }
  };

  // ── Delete entry ─────────────────────────────────────────────────────────────
  const deleteEntry = async (id) => {
    await supabase.from("fuel_prices").delete().eq("id", id);
  };

  // ── Derived data ─────────────────────────────────────────────────────────────
  const cheapest = useMemo(() => {
    return Object.fromEntries(["petrol","diesel","kerosene"].map(fuel => {
      const valid = entries.filter(e => e[fuel] != null);
      if (!valid.length) return [fuel, null];
      return [fuel, valid.reduce((m, e) => +e[fuel] < +m[fuel] ? e : m)];
    }));
  }, [entries]);

  const trendData = useMemo(() => {
    const byDate = {};
    entries.forEach(e => {
      if (!byDate[e.date]) byDate[e.date] = { petrol:[], diesel:[], kerosene:[] };
      if (e.petrol   != null) byDate[e.date].petrol.push(+e.petrol);
      if (e.diesel   != null) byDate[e.date].diesel.push(+e.diesel);
      if (e.kerosene != null) byDate[e.date].kerosene.push(+e.kerosene);
    });
    return Object.entries(byDate)
      .sort(([a],[b]) => a.localeCompare(b))
      .map(([date, v]) => ({
        date,
        Petrol:   avg(v.petrol),
        Diesel:   avg(v.diesel),
        Kerosene: avg(v.kerosene),
      }));
  }, [entries]);

  const mapData = useMemo(() => {
    const latest = {};
    entries.forEach(e => {
      if (e[mapFuel] != null && (!latest[e.county] || e.date >= latest[e.county].date))
        latest[e.county] = e;
    });
    return latest;
  }, [entries, mapFuel]);

  const mapValues = Object.values(mapData).map(e => +e[mapFuel]).filter(Boolean);
  const mapMin    = mapValues.length ? Math.min(...mapValues) : 0;
  const mapMax    = mapValues.length ? Math.max(...mapValues) : 0;

  const getMapColor = (val) => {
    if (!val) return "#e5e7eb";
    const t = mapMax === mapMin ? 0.5 : (val - mapMin) / (mapMax - mapMin);
    return `rgb(${Math.round(34+(220-34)*t)},${Math.round(197+(38-197)*t)},${Math.round(94+(38-94)*t)})`;
  };

  const filteredEntries = useMemo(() =>
    entries.filter(e => filterCounty === "All" || e.county === filterCounty),
    [entries, filterCounty]);

  const sortedEntries = useMemo(() => {
    return [...filteredEntries].sort((a, b) => {
      const va = a[sortBy], vb = b[sortBy];
      if (va == null && vb == null) return 0;
      if (va == null) return 1; if (vb == null) return -1;
      if (typeof va === "number" || !isNaN(va))
        return sortDir === "asc" ? +va - +vb : +vb - +va;
      return sortDir === "asc"
        ? String(va).localeCompare(String(vb))
        : String(vb).localeCompare(String(va));
    });
  }, [filteredEntries, sortBy, sortDir]);

  const toggleSort = (col) => {
    if (sortBy === col) setSortDir(d => d==="asc"?"desc":"asc");
    else { setSortBy(col); setSortDir("asc"); }
  };

  // ── Styles ───────────────────────────────────────────────────────────────────
  const inputSt = {
    border:"1px solid #d1d5db", borderRadius:6, padding:"8px 10px",
    fontSize:14, width:"100%", boxSizing:"border-box", outline:"none", fontFamily:"inherit",
  };
  const cardSt = {
    background:"#fff", borderRadius:12, padding:22,
    boxShadow:"0 1px 4px rgba(0,0,0,0.07)", border:"1px solid #bbf7d0",
  };
  const SortArrow = ({ col }) =>
    <span style={{opacity:0.45,fontSize:11}}>
      {sortBy===col ? (sortDir==="asc"?" ▲":" ▼") : " ⇅"}
    </span>;

  // ── Loading screen ────────────────────────────────────────────────────────────
  if (loading) return (
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100vh",gap:16,background:"#f0fdf4"}}>
      <div style={{fontSize:48}}>⛽</div>
      <div style={{fontSize:18,color:"#166534",fontWeight:600}}>Loading fuel prices…</div>
      <div style={{width:40,height:4,background:"#bbf7d0",borderRadius:2,overflow:"hidden"}}>
        <div style={{height:"100%",background:"#16a34a",animation:"slide 1s infinite",borderRadius:2}}/>
      </div>
      <style>{`@keyframes slide{0%{transform:translateX(-100%)}100%{transform:translateX(400%)}}`}</style>
    </div>
  );

  // ── Render ───────────────────────────────────────────────────────────────────
  return (
    <div style={{fontFamily:"'Segoe UI',system-ui,sans-serif",background:"#f0fdf4",minHeight:"100vh",paddingBottom:60}}>

      {/* ── Header ── */}
      <div style={{background:"linear-gradient(135deg,#14532d,#166534)",padding:"22px 32px",boxShadow:"0 2px 10px rgba(0,0,0,0.25)"}}>
        <div style={{maxWidth:1100,margin:"0 auto",display:"flex",alignItems:"center",gap:14,flexWrap:"wrap"}}>
          <span style={{fontSize:40}}>🇮🇪</span>
          <div>
            <h1 style={{margin:0,fontSize:26,fontWeight:700,color:"#fff",letterSpacing:"-0.3px"}}>
              Ireland Fuel Price Tracker
            </h1>
            <p style={{margin:"3px 0 0",color:"#86efac",fontSize:13}}>
              Crowdsourced petrol, diesel &amp; kerosene prices across all 32 counties
            </p>
          </div>
          <div style={{marginLeft:"auto",display:"flex",gap:10,alignItems:"center",flexWrap:"wrap"}}>
            {liveCount > 0 && (
              <span style={{background:"rgba(134,239,172,0.2)",border:"1px solid #86efac",borderRadius:20,padding:"4px 12px",color:"#86efac",fontSize:12,fontWeight:600}}>
                🔴 LIVE
              </span>
            )}
            <span style={{background:"rgba(255,255,255,0.15)",borderRadius:20,padding:"6px 16px",color:"#fff",fontSize:13,fontWeight:600}}>
              {entries.length} {entries.length===1?"entry":"entries"}
            </span>
          </div>
        </div>
      </div>

      <div style={{maxWidth:1100,margin:"0 auto",padding:"24px 16px"}}>

        {/* ── DB error banner ── */}
        {dbError && (
          <div style={{background:"#fef2f2",border:"1px solid #fecaca",borderRadius:10,padding:"14px 18px",marginBottom:18,color:"#dc2626",fontSize:14}}>
            ⚠️ Database error: {dbError}
          </div>
        )}

        {/* ── Add Entry Form ── */}
        <div style={{...cardSt,marginBottom:22}}>
          <h2 style={{margin:"0 0 16px",fontSize:17,color:"#166534",display:"flex",alignItems:"center",gap:8}}>
            ➕ Add a Price
          </h2>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(148px,1fr))",gap:12}}>

            <div>
              <label style={{fontSize:12,color:"#6b7280",fontWeight:600,display:"block",marginBottom:4,textTransform:"uppercase",letterSpacing:"0.05em"}}>County *</label>
              <select value={form.county} onChange={e=>setForm(f=>({...f,county:e.target.value}))} style={inputSt}>
                {COUNTIES.map(c=><option key={c}>{c}</option>)}
              </select>
            </div>

            <div>
              <label style={{fontSize:12,color:"#6b7280",fontWeight:600,display:"block",marginBottom:4,textTransform:"uppercase",letterSpacing:"0.05em"}}>Station Name</label>
              <input placeholder="e.g. Circle K, Applegreen" value={form.station}
                onChange={e=>setForm(f=>({...f,station:e.target.value}))}
                onKeyDown={e=>e.key==="Enter"&&addEntry()}
                style={inputSt}/>
            </div>

            {["petrol","diesel","kerosene"].map(fuel=>(
              <div key={fuel}>
                <label style={{fontSize:12,fontWeight:700,display:"block",marginBottom:4,textTransform:"uppercase",letterSpacing:"0.05em",color:FUEL_COLORS[fuel]}}>
                  {FUEL_ICONS[fuel]} {fuel} (€/L)
                </label>
                <input type="number" step="0.001" min="0.5" max="5"
                  placeholder={fuel==="petrol"?"1.729":fuel==="diesel"?"1.689":"1.050"}
                  value={form[fuel]}
                  onChange={e=>setForm(f=>({...f,[fuel]:e.target.value}))}
                  onKeyDown={e=>e.key==="Enter"&&addEntry()}
                  style={{...inputSt,borderColor:errors[fuel]?"#ef4444":"#d1d5db"}}/>
                {errors[fuel]&&<span style={{color:"#ef4444",fontSize:11,marginTop:2,display:"block"}}>{errors[fuel]}</span>}
              </div>
            ))}

            <div>
              <label style={{fontSize:12,color:"#6b7280",fontWeight:600,display:"block",marginBottom:4,textTransform:"uppercase",letterSpacing:"0.05em"}}>Date *</label>
              <input type="date" value={form.date} onChange={e=>setForm(f=>({...f,date:e.target.value}))} style={inputSt}/>
            </div>

          </div>

          {errors.price&&(
            <p style={{color:"#ef4444",margin:"10px 0 0",fontSize:13,background:"#fef2f2",padding:"8px 12px",borderRadius:6,border:"1px solid #fecaca"}}>
              ⚠ {errors.price}
            </p>
          )}

          <div style={{marginTop:16,display:"flex",alignItems:"center",gap:12}}>
            <button onClick={addEntry} disabled={saving} style={{
              background: saving?"#86efac":"#16a34a",color:"#fff",border:"none",borderRadius:8,
              padding:"10px 28px",fontSize:15,fontWeight:700,cursor:saving?"not-allowed":"pointer",
              boxShadow:"0 2px 4px rgba(22,101,52,0.3)",fontFamily:"inherit",transition:"background 0.2s",
            }}>
              {saving ? "Saving…" : "Add Entry"}
            </button>
            <span style={{fontSize:12,color:"#9ca3af"}}>Data is shared with everyone in real-time 🌍</span>
          </div>
        </div>

        {/* ── Cheapest Cards ── */}
        {entries.length > 0 && (
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))",gap:14,marginBottom:22}}>
            {[
              ["petrol",  "#16a34a","#f0fdf4","#bbf7d0"],
              ["diesel",  "#2563eb","#eff6ff","#bfdbfe"],
              ["kerosene","#d97706","#fffbeb","#fde68a"],
            ].map(([fuel,color,bg,border])=>(
              <div key={fuel} style={{background:bg,borderRadius:12,padding:18,border:`1px solid ${border}`,boxShadow:"0 1px 3px rgba(0,0,0,0.06)"}}>
                <div style={{fontSize:12,color:"#6b7280",fontWeight:600,textTransform:"uppercase",letterSpacing:"0.06em",marginBottom:6}}>
                  🏆 Cheapest {fuel}
                </div>
                {cheapest[fuel] ? (
                  <>
                    <div style={{fontSize:32,fontWeight:800,color,lineHeight:1.1}}>{fmt(cheapest[fuel][fuel])}</div>
                    <div style={{fontSize:14,color:"#374151",marginTop:6,fontWeight:500}}>
                      {cheapest[fuel].county}
                      {cheapest[fuel].station&&<span style={{color:"#6b7280"}}> · {cheapest[fuel].station}</span>}
                    </div>
                    <div style={{fontSize:12,color:"#9ca3af",marginTop:2}}>{cheapest[fuel].date}</div>
                  </>
                ):(
                  <div style={{fontSize:15,color:"#9ca3af",paddingTop:8}}>No data yet</div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* ── Tabs ── */}
        {entries.length > 0 && (
          <>
            <div style={{display:"flex",gap:0,borderBottom:"2px solid #bbf7d0",overflowX:"auto"}}>
              {[["table","📋 Price Table"],["chart","📈 Trends"],["map","🗺️ Map View"]].map(([tab,label])=>(
                <button key={tab} onClick={()=>setActiveTab(tab)} style={{
                  padding:"10px 22px",border:"none",cursor:"pointer",fontFamily:"inherit",
                  background:activeTab===tab?"#16a34a":"transparent",
                  color:activeTab===tab?"#fff":"#6b7280",
                  fontWeight:600,fontSize:14,borderRadius:"8px 8px 0 0",transition:"all 0.15s",whiteSpace:"nowrap",
                }}>{label}</button>
              ))}
            </div>

            {/* ── TABLE ── */}
            {activeTab==="table"&&(
              <div style={{...cardSt,borderTopLeftRadius:0,borderTop:"none",padding:0,overflow:"hidden"}}>
                <div style={{padding:"12px 18px",background:"#f9fafb",borderBottom:"1px solid #f3f4f6",display:"flex",flexWrap:"wrap",gap:10,alignItems:"center"}}>
                  <label style={{fontSize:13,color:"#374151",fontWeight:500}}>Filter:</label>
                  <select value={filterCounty} onChange={e=>setFilterCounty(e.target.value)}
                    style={{...inputSt,width:"auto",padding:"5px 10px",fontSize:13}}>
                    <option>All</option>
                    {COUNTIES.map(c=><option key={c}>{c}</option>)}
                  </select>
                  <span style={{fontSize:12,color:"#9ca3af",marginLeft:"auto"}}>{sortedEntries.length} entries</span>
                </div>
                <div style={{overflowX:"auto"}}>
                  <table style={{width:"100%",borderCollapse:"collapse",fontSize:14}}>
                    <thead>
                      <tr style={{background:"#f9fafb"}}>
                        {[["county","County"],["station","Station"],["petrol","⛽ Petrol"],["diesel","🛢️ Diesel"],["kerosene","🔥 Kerosene"],["date","Date"]].map(([col,label])=>(
                          <th key={col} onClick={()=>toggleSort(col)} style={{
                            padding:"11px 14px",textAlign:"left",fontWeight:600,color:"#374151",
                            cursor:"pointer",userSelect:"none",whiteSpace:"nowrap",
                            borderBottom:"2px solid #e5e7eb",fontSize:13,
                          }}>{label}<SortArrow col={col}/></th>
                        ))}
                        <th style={{padding:"11px 14px",borderBottom:"2px solid #e5e7eb"}}></th>
                      </tr>
                    </thead>
                    <tbody>
                      {sortedEntries.map((e,i)=>(
                        <tr key={e.id} style={{background:i%2===0?"#fff":"#fafafa",borderBottom:"1px solid #f3f4f6"}}
                          onMouseEnter={ev=>ev.currentTarget.style.background="#f0fdf4"}
                          onMouseLeave={ev=>ev.currentTarget.style.background=i%2===0?"#fff":"#fafafa"}>
                          <td style={{padding:"10px 14px",fontWeight:600,color:"#1f2937"}}>{e.county}</td>
                          <td style={{padding:"10px 14px",color:"#6b7280"}}>{e.station||"—"}</td>
                          <td style={{padding:"10px 14px",color:"#16a34a",fontWeight:700}}>
                            {fmt(e.petrol)}{e.id===cheapest.petrol?.id&&e.petrol!=null?" 🏆":""}
                          </td>
                          <td style={{padding:"10px 14px",color:"#2563eb",fontWeight:700}}>
                            {fmt(e.diesel)}{e.id===cheapest.diesel?.id&&e.diesel!=null?" 🏆":""}
                          </td>
                          <td style={{padding:"10px 14px",color:"#d97706",fontWeight:700}}>
                            {fmt(e.kerosene)}{e.id===cheapest.kerosene?.id&&e.kerosene!=null?" 🏆":""}
                          </td>
                          <td style={{padding:"10px 14px",color:"#9ca3af",fontSize:12,whiteSpace:"nowrap"}}>{e.date}</td>
                          <td style={{padding:"10px 14px"}}>
                            <button onClick={()=>deleteEntry(e.id)} style={{
                              background:"none",border:"1px solid #fca5a5",borderRadius:6,
                              color:"#ef4444",cursor:"pointer",padding:"4px 10px",fontSize:12,
                              fontWeight:500,fontFamily:"inherit",
                            }}>✕</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* ── CHART ── */}
            {activeTab==="chart"&&(
              <div style={{...cardSt,borderTopLeftRadius:0,borderTop:"none"}}>
                <h3 style={{margin:"0 0 4px",color:"#166534",fontSize:17,fontWeight:700}}>Average Price Trends</h3>
                <p style={{margin:"0 0 20px",color:"#9ca3af",fontSize:13}}>Daily average across all submitted prices</p>
                {trendData.length<2?(
                  <div style={{textAlign:"center",padding:"50px 20px",color:"#9ca3af"}}>
                    <div style={{fontSize:36,marginBottom:10}}>📈</div>
                    Add entries from at least <strong>two different dates</strong> to see trends
                  </div>
                ):(
                  <ResponsiveContainer width="100%" height={360}>
                    <LineChart data={trendData} margin={{top:5,right:30,left:10,bottom:10}}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6"/>
                      <XAxis dataKey="date" tick={{fontSize:12}} tickLine={false}/>
                      <YAxis tickFormatter={v=>`€${v.toFixed(2)}`} tick={{fontSize:12}} tickLine={false} domain={["auto","auto"]} width={60}/>
                      <Tooltip formatter={(v,name)=>[`€${Number(v).toFixed(3)}`,name]} contentStyle={{borderRadius:8,border:"1px solid #e5e7eb",fontSize:13}}/>
                      <Legend/>
                      <Line type="monotone" dataKey="Petrol"   stroke="#16a34a" strokeWidth={2.5} dot={{r:5}} connectNulls/>
                      <Line type="monotone" dataKey="Diesel"   stroke="#2563eb" strokeWidth={2.5} dot={{r:5}} connectNulls/>
                      <Line type="monotone" dataKey="Kerosene" stroke="#f59e0b" strokeWidth={2.5} dot={{r:5}} connectNulls/>
                    </LineChart>
                  </ResponsiveContainer>
                )}
              </div>
            )}

            {/* ── MAP ── */}
            {activeTab==="map"&&(
              <div style={{...cardSt,borderTopLeftRadius:0,borderTop:"none"}}>
                <div style={{display:"flex",flexWrap:"wrap",gap:12,marginBottom:20,alignItems:"center"}}>
                  <h3 style={{margin:0,color:"#166534",fontSize:17,fontWeight:700}}>County Price Map</h3>
                  <div style={{display:"flex",gap:6}}>
                    {["petrol","diesel","kerosene"].map(f=>(
                      <button key={f} onClick={()=>setMapFuel(f)} style={{
                        padding:"6px 16px",borderRadius:20,border:"2px solid",
                        borderColor:mapFuel===f?FUEL_COLORS[f]:"#e5e7eb",
                        background:mapFuel===f?FUEL_COLORS[f]:"#fff",
                        color:mapFuel===f?"#fff":"#374151",
                        cursor:"pointer",fontSize:13,fontWeight:600,fontFamily:"inherit",transition:"all 0.15s",
                      }}>{FUEL_ICONS[f]} {f.charAt(0).toUpperCase()+f.slice(1)}</button>
                    ))}
                  </div>
                </div>
                <div style={{display:"flex",flexWrap:"wrap",gap:24,alignItems:"flex-start"}}>
                  <div style={{flex:"0 0 auto"}}>
                    <svg viewBox="0 0 100 105" style={{width:340,height:357,borderRadius:10,border:"1px solid #e5e7eb",display:"block"}}>
                      <rect width="100" height="105" fill="#dbeafe" rx="6"/>
                      <path d="M50,6 C40,5 28,10 22,18 C15,26 14,32 16,40 C14,46 12,52 18,60 C14,68 20,78 28,84 C36,90 44,92 52,90 C60,92 68,88 74,80 C80,74 78,66 76,60 C80,54 82,48 80,40 C82,34 80,26 74,20 C68,14 58,7 50,6 Z"
                        fill="#d1fae5" stroke="#6ee7b7" strokeWidth="0.8" opacity="0.8"/>
                      {Object.entries(COORDS).map(([county,[x,y]])=>{
                        const entry=mapData[county]; const val=entry?.[mapFuel];
                        const color=getMapColor(val?+val:null);
                        const isCheapest=val&&entry?.id===cheapest[mapFuel]?.id;
                        return (
                          <g key={county}>
                            {isCheapest&&<circle cx={x} cy={y} r={7} fill="none" stroke="#fbbf24" strokeWidth="1.5" opacity="0.8"/>}
                            <circle cx={x} cy={y} r={val?4.8:3} fill={color} stroke="#fff" strokeWidth="0.8" opacity={0.92}/>
                            <title>{county}: {val?fmt(+val):"No data"}{isCheapest?" 🏆 Cheapest!":""}</title>
                          </g>
                        );
                      })}
                    </svg>
                    {mapValues.length>0&&(
                      <div style={{marginTop:10,padding:"10px 14px",background:"#f9fafb",borderRadius:8,border:"1px solid #e5e7eb"}}>
                        <div style={{fontSize:11,color:"#6b7280",marginBottom:5,fontWeight:600,textTransform:"uppercase",letterSpacing:"0.05em"}}>Price Range</div>
                        <div style={{display:"flex",alignItems:"center",gap:8}}>
                          <span style={{fontSize:11,fontWeight:600}}>€{mapMin.toFixed(3)}</span>
                          <div style={{flex:1,height:10,borderRadius:5,background:"linear-gradient(to right,rgb(34,197,94),rgb(220,38,38))"}}/>
                          <span style={{fontSize:11,fontWeight:600}}>€{mapMax.toFixed(3)}</span>
                        </div>
                      </div>
                    )}
                  </div>
                  <div style={{flex:1,minWidth:200}}>
                    <h4 style={{margin:"0 0 10px",color:"#374151",fontSize:14,fontWeight:600}}>
                      {mapFuel.charAt(0).toUpperCase()+mapFuel.slice(1)} by county
                    </h4>
                    <div style={{maxHeight:380,overflowY:"auto",borderRadius:8,border:"1px solid #e5e7eb"}}>
                      {COUNTIES.map((county,i)=>{
                        const val=mapData[county]?.[mapFuel];
                        const isCheapest=mapData[county]?.id===cheapest[mapFuel]?.id;
                        return (
                          <div key={county} style={{
                            display:"flex",justifyContent:"space-between",alignItems:"center",
                            padding:"7px 12px",borderBottom:i<COUNTIES.length-1?"1px solid #f3f4f6":"none",
                            background:isCheapest?"#f0fdf4":i%2===0?"#fff":"#fafafa",
                          }}>
                            <span style={{fontSize:13,color:isCheapest?"#166534":"#374151",fontWeight:isCheapest?600:400}}>{county}</span>
                            <span style={{fontWeight:700,fontSize:14,color:val?FUEL_COLORS[mapFuel]:"#d1d5db"}}>
                              {val?fmt(+val):"—"}{isCheapest?" 🏆":""}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </>
        )}

        {/* ── Empty state ── */}
        {entries.length===0&&!loading&&(
          <div style={{textAlign:"center",padding:"70px 20px",color:"#9ca3af"}}>
            <div style={{fontSize:56,marginBottom:16}}>⛽</div>
            <h3 style={{margin:"0 0 8px",fontSize:20,color:"#6b7280",fontWeight:700}}>No prices yet</h3>
            <p style={{margin:0,fontSize:14}}>Be the first to add a fuel price for your county!</p>
          </div>
        )}

        <p style={{textAlign:"center",fontSize:12,color:"#d1d5db",marginTop:32}}>
          Built for Ireland 🇮🇪 · Prices are crowdsourced and updated in real-time
        </p>
      </div>
    </div>
  );
}
